from pytrends.request import TrendReq
import pandas as pd

# 1. pytrends 연결
pytrends = TrendReq(hl='ko', tz=540)

# 2. 분석할 음식 키워드 (여기에 후보군을 늘려도 됨)
keywords = [
    "냉면","삼계탕","붕어빵","팥빙수","호떡",
]

# 3. 구글 트렌드 데이터 요청 (지난 12개월, 한국)
pytrends.build_payload(keywords, timeframe="today 12-m", geo="KR")

# 4. 검색량 데이터 가져오기
df = pytrends.interest_over_time()

# 5. 월/계절 컬럼 추가
df["month"] = df.index.month

def get_season(month):
    if month in [12, 1, 2]:
        return "겨울"
    elif month in [3, 4, 5]:
        return "봄"
    elif month in [6, 7, 8]:
        return "여름"
    else:
        return "가을"

df["season"] = df["month"].apply(get_season)

# 6. 계절별 평균 검색량 계산
season_avg = df.groupby("season")[keywords].mean().T

# 7. 계절별 Top10 뽑기
season_top10 = {}
for season in season_avg.columns:
    season_top10[season] = season_avg[season].sort_values(ascending=False).head(10).index.tolist()

# 8. 결과 출력
for season, foods in season_top10.items():
    print(f"📊 {season} 인기 음식 TOP10")
    print(", ".join(foods))
    print()
