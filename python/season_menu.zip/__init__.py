# season_menu/__init__.py
print("패키지 season_menu 로드됨 🚀")