import pandas as pd
import pymysql
import plotly.express as px
from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# CORS 설정
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# DB 연결
def get_connection():
    return pymysql.connect(
        host="localhost",
        user="pickdbuser",
        password="1234",
        db="pickdb",
        charset="utf8mb4"
    )


# 1) 카테고리별 주문 비율 차트
@app.get("/chart/category")
def category_chart(user_email: str):
    conn = get_connection()
    #쿼리문
    sql = """
    SELECT r.category_name, COUNT(f.id) AS order_count
    FROM funding f
    JOIN restaurant r ON f.restaurant_id = r.id
    WHERE f.member_email = %s
      AND f.status = 'COMPLETED'
    GROUP BY r.category_name
    """
    df = pd.read_sql(sql, conn, params=[user_email])
    conn.close()
    
    if df.empty:
        return {"message": "카테고리 데이터 없음"}

    # 제일 많이 주문한 카테고리
    top_row = df.loc[df["order_count"].idxmax()]
    summary_text = f"{top_row['category_name']} ({top_row['order_count']}회)를 가장 많이 주문했어요!"

    # 파이차트 생성 + 크기 고정
    fig = px.pie(
        df,
        names="category_name",
        values="order_count",
        title="카테고리별 펀딩 비율",
        hole=0.3
    )
    fig.update_layout(
        height=400, width=600,
        margin=dict(l=20, r=20, t=40, b=40)
    )

    html_chart = fig.to_html(full_html=False)

    final_html = f"""
    <div style="text-align:center;">
        {html_chart}
        <p style="font-size:18px; font-weight:bold; color:#333;">
            {summary_text}
        </p>
    </div>
    """

    return Response(content=final_html, media_type="text/html")

# 카테고리별 주문 비율 + 추천
@app.get("/recommend/top-restaurants")
def recommend_top_restaurants(user_email: str):
    conn = get_connection()

    sql_top = """
    SELECT r.category_name, COUNT(f.id) AS order_count
    FROM funding f
    JOIN restaurant r ON f.restaurant_id = r.id
    WHERE f.member_email = %s
      AND f.status = 'COMPLETED'
    GROUP BY r.category_name
    ORDER BY order_count DESC
    LIMIT 1
    """
    try:
        top_df = pd.read_sql(sql_top, conn, params=[user_email])
    except Exception as e:
        conn.close()
        return {"error": "SQL 실행 오류", "detail": str(e)}

    # 결과 체크
    if top_df.empty:
        conn.close()
        return {"message": "추천할 카테고리가 없습니다.", "data": []}

    if "category_name" not in top_df.columns:
        conn.close()
        return {"error": "DB 결과에 category_name 없음", "columns": list(top_df.columns)}

    top_category = top_df.iloc[0]["category_name"]

    # 카테고리 음식점 추천
    sql_rec = """
    SELECT id, name, category_name, road_address_name
    FROM restaurant
    WHERE category_name = %s
    ORDER BY RAND()
    LIMIT 5
    """
    try:
        rec_df = pd.read_sql(sql_rec, conn, params=[top_category])
    except Exception as e:
        conn.close()
        return {"error": "추천 SQL 실행 오류", "detail": str(e)}

    conn.close()

    return {
        "topCategory": str(top_category),
        "recommended": rec_df.to_dict(orient="records")
    }

# 자주 주문한 식당 TOP 5
@app.get("/chart/restaurant")
def restaurant_chart(user_email: str):
    conn = get_connection()
    sql = """
    SELECT r.name AS restaurant_name, COUNT(f.id) AS order_count
    FROM funding f
    JOIN restaurant r ON f.restaurant_id = r.id
    WHERE f.member_email = %s
      AND f.status = 'COMPLETED'
    GROUP BY r.name
    ORDER BY order_count DESC
    LIMIT 5
    """
    try:
        df = pd.read_sql(sql, conn, params=[user_email])
    except Exception as e:
        conn.close()
        return {"error": "SQL 실행 오류", "detail": str(e)}

    conn.close()

    if df.empty:
        return {"message": "식당 데이터 없음", "data": []}

    if "restaurant_name" not in df.columns:
        return {"error": "DB 결과에 restaurant_name 없음", "columns": list(df.columns)}

    # 제일 많이 주문한 식당
    top_row = df.loc[df["order_count"].idxmax()]
    summary_text = f"{top_row['restaurant_name']} ({top_row['order_count']}회)에서 가장 많이 펀딩했어요!"

    # 바차트 생성
    fig = px.bar(
        df,
        x="restaurant_name",
        y="order_count",
        text="order_count",
    )
    fig.update_traces(textposition="outside", marker_color="skyblue")
    fig.update_layout(
        height=400, width=600,
        margin=dict(l=40, r=40, t=50, b=100),
        yaxis=dict(dtick=1)
    )

    html_chart = fig.to_html(full_html=False)

    final_html = f"""
    <div style="text-align:center;">
        {html_chart}
        <p style="font-size:18px; font-weight:bold; color:#333;">
            {summary_text}
        </p>
    </div>
    """

    return Response(content=final_html, media_type="text/html")
